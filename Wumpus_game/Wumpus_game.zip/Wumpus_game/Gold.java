public class Gold extends GameItem {
    public Gold() {
        super('g');
    }
}
