public class Wumpus extends GameItem {
    public Wumpus() {
        super('W');
    }
}

