public class ClearGround extends GameItem {
    public ClearGround() {
        super('.');
    }
}

