public class Pit extends GameItem {
    public Pit() {
        super('p');
    }
}

